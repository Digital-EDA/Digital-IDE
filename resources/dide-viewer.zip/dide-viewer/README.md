dide-viewer
    - view
        - index.html
        - css
        - js
        - ...