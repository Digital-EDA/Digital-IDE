self.onmessage = async event => {
    const { arrayBuffer, vcdSource, wasmBinary } = event.data;
    eval(vcdSource);
    const moduleArg = { wasmBinary };
    const vcdstream = await makeVcdStream(moduleArg);
    vcdstream.consume(arrayBuffer);
    const info = vcdstream.getBasicInfo();
    self.postMessage(info);
};